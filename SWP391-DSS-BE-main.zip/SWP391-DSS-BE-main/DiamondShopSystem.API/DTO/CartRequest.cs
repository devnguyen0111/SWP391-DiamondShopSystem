﻿namespace DiamondShopSystem.API.DTO
{
    public class CartRequest
    {
        public int id {  get; set; }
        public int pid { get; set; }
    }
}
