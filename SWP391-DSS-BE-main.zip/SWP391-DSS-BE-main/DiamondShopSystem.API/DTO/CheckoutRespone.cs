﻿namespace DiamondShopSystem.API.DTO
{
    public class CheckoutRespone
    {
    }
    public class ContactInfo { }
    public class ShipppingAddress
    {

    }
    public class ShippingMethod { }
    public class ListOfItems { }

}
