﻿namespace DiamondShopSystem.API.DTO
{
    public class EmailResponse
    {
        public string Email { get; set; }

        public string Url { get; set; }
    }
    public class HtmlContentModel
    {
        public string HtmlContent { get; set; }
    }
}
