﻿namespace DiamondShopSystem.API.DTO
{
    public class UserResponse
    {
        public int UserId { get; set; }

        public string Email { get; set; }

        public string Password { get; set; }

        public string Status { get; set; }

        public string Role { get; set; }
    }
}
