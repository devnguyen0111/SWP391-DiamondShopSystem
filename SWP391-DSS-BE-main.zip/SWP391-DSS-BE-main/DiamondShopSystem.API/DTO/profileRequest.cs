﻿namespace DiamondShopSystem.API.DTO
{
    public class profileRequest
    {
        public int id {  get; set; }
        public string firstName {  get; set; }
        public string lastName { get; set; }

        public string phonenumber {  get; set; }
    }
}
